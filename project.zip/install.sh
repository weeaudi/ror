gem install rails
sudo apt update
sudo apt install freetds-dev -y
bundle install