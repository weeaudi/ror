class ApplicationController < ActionController::Base

  def not_found(message: "Not Found")
    puts message
    render json: {error: message}, status: 404
  end

end
