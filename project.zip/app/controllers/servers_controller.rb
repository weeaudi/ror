# app/controllers/servers_controller.rb
class ServersController < ApplicationController
  before_action :authenticate_user!

  def index
    email = current_user.email
    @servers = PanelApiInterface.find_all_servers(email: email, api_key: Rails.application.credentials.dig(:UsSe_R))
  end

  def index_json
    email = current_user.email
    render json: PanelApiInterface.find_all_servers(email: email, api_key: Rails.application.credentials.dig(:UsSe_R))
  end

  def show
    server = PanelApiInterface.find(id: params[:id], api_key: Rails.application.credentials.dig(:UsSe_R))
    unless server.empty?
      @server = server[0]['attributes']
    else
      not_found message: "Server not found!"
    end
  end

  def show_json
    server = PanelApiInterface.find(id: params[:id], api_key: Rails.application.credentials.dig(:UsSe_R))
    unless server.empty?
      render json: server[0]['attributes']
    else
      not_found message: "Server not found!"
    end
  end

end
